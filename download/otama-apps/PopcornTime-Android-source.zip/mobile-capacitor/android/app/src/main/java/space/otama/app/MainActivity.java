package space.otama.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
